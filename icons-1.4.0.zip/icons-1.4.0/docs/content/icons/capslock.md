---
title: Capslock
categories:
  - UI and keyboard
tags:
  - key
---
