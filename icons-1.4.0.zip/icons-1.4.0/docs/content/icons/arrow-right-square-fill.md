---
title: Arrow right square fill
layout: icon
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
